import { listingService } from '@/services/listingService';
import ListingCard from '@/components/listings/ListingCard';
import { SlidersHorizontal, Search } from 'lucide-react';

// In Next.js 15, searchParams is passed as a Promise to server components
type Props = {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
};

export default async function AllListingsPage({ searchParams }: Props) {
  // 1. Await the URL parameters sent from the Homepage Search Bar
  const params = await searchParams;
  const locationQuery = typeof params.location === 'string' ? params.location : '';
  const typeQuery = typeof params.type === 'string' ? params.type : '';

  // 2. Fetch from Supabase. 
  // If typeQuery is empty, it fetches everything. If it has a value (e.g., 'duplex'), it filters the database.
  let listings = await listingService.filterListings({
    type: typeQuery || undefined,
  });

  // 3. Filter by location
  // We do a quick JavaScript filter here to check if the location or title matches the search text
  if (locationQuery) {
    const lowerQuery = locationQuery.toLowerCase();
    listings = listings.filter(listing => 
      listing.location.toLowerCase().includes(lowerQuery) ||
      listing.title.toLowerCase().includes(lowerQuery)
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pt-28 pb-20 transition-colors">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Page Header */}
        <div className="mb-10">
          <h1 className="text-4xl font-heading font-bold text-slate-900 dark:text-white mb-4 transition-colors">
            {locationQuery || typeQuery ? 'Search Results' : 'Browse Properties'}
          </h1>
          <p className="text-slate-600 dark:text-slate-400 text-lg transition-colors">
            Showing {listings.length} available {listings.length === 1 ? 'property' : 'properties'}
            {locationQuery && ` near "${locationQuery}"`}
            {typeQuery && ` of type "${typeQuery}"`}.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-10">
          
          {/* STATIC FILTER SIDEBAR (Visual Layout for now) */}
          <aside className="w-full lg:w-72 shrink-0">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sticky top-28 shadow-sm transition-colors">
              <div className="flex items-center gap-2 font-heading font-bold text-lg text-slate-900 dark:text-white mb-6">
                <SlidersHorizontal size={20} className="text-blue-600 dark:text-blue-500" />
                Filters
              </div>

              {/* Sidebar Search Input */}
              <div className="mb-6 relative">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  defaultValue={locationQuery}
                  placeholder="Search location..." 
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl pl-10 pr-4 py-3 text-sm text-slate-900 dark:text-white outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              {/* Sidebar Property Type Filter */}
              <div className="space-y-6">
                <div>
                  <h4 className="font-semibold text-slate-900 dark:text-white mb-3 text-sm uppercase tracking-wider">Property Type</h4>
                  <div className="space-y-3 flex flex-col">
                    {['apartment', 'duplex', 'studio', 'bungalow'].map((type) => (
                      <label key={type} className="flex items-center gap-3 text-slate-600 dark:text-slate-400 text-sm cursor-pointer hover:text-blue-600 dark:hover:text-blue-400">
                        <input 
                          type="checkbox" 
                          defaultChecked={typeQuery === type}
                          className="rounded border-slate-300 dark:border-slate-700 text-blue-600 focus:ring-blue-500 bg-transparent" 
                        />
                        <span className="capitalize">{type}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
              
              <button className="w-full mt-8 bg-blue-600 text-white py-3 rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors">
                Apply Filters
              </button>
            </div>
          </aside>

          {/* LISTINGS GRID */}
          <div className="flex-1">
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {listings.map((listing) => (
                <div key={listing.id} className="relative h-full">
                  <ListingCard listing={listing} />
                </div>
              ))}
            </div>
            
            {/* EMPTY STATE: Shown if search matches zero properties */}
            {listings.length === 0 && (
              <div className="flex flex-col items-center justify-center py-20 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 border-dashed transition-colors">
                <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mb-4">
                  <Search className="text-slate-400" size={24} />
                </div>
                <h3 className="text-xl font-heading font-bold text-slate-900 dark:text-white mb-2">No properties found</h3>
                <p className="text-slate-500 dark:text-slate-400 text-center max-w-sm">
                  We couldn't find any properties matching your current search. Try adjusting your filters or location.
                </p>
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
}